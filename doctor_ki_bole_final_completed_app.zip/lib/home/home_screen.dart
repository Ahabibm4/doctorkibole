import 'package:flutter/material.dart';
import '../photo_upload_screen.dart';
import '../pdf_upload_screen.dart';
import '../manual_entry_screen.dart';
import '../symptom_checker_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Doctor Ki Bole")),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton.icon(
            icon: const Icon(Icons.photo_camera),
            label: const Text("ছবি আপলোড করুন"),
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PhotoUploadScreen()));
            },
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text("PDF রিপোর্ট আপলোড করুন"),
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PDFUploadScreen()));
            },
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.edit),
            label: const Text("ম্যানুয়ালি রিপোর্ট দিন"),
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ManualEntryScreen()));
            },
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.mic),
            label: const Text("উপসর্গ বলুন"),
            onPressed: () {
              Navigator.push(context,
                MaterialPageRoute(builder: (_) => const SymptomCheckerScreen()));
            },
          ),
        ],
      ),
    );
  }
}
